# Kylo Ren CSS Page Preloader

An HTML &amp; CSS Kylo Ren page preloader. Watch the [timelapse video](https://www.youtube.com/watch?v=_iV5WjqIfuU). By Petr Urbánek.

![Kylo Ren CSS Page Preloader](https://tympanus.net/codrops/wp-content/uploads/2017/10/KyloRenFeatured.png)

[Article on Codrops](https://tympanus.net/codrops/?p=32648)

[Demo](http://tympanus.net/Development/KyloRenPreloader/)

This demo is kindly sponsored by [PageCloud](https://goo.gl/FtPPs4), the website builder you'll love to use.

## License
This resource can be used freely if integrated or build upon in personal or commercial projects such as websites, web apps and web templates intended for sale. It is not allowed to take the resource "as-is" and sell it, redistribute, re-publish it, or sell "pluginized" versions of it. Free plugins built using this resource should have a visible mention and link to the original work. Always consider the licenses of all included libraries, scripts and images used.

## Misc

Follow Codrops: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/codrops), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/), [Instagram](https://www.instagram.com/codropsss/)

[© Codrops 2017](http://www.codrops.com)





